---
name: wms-auth-probe
description: Probe WISE/WMS auth env injection for read-only exception-line pulls (Joliet LT_ORG-61213)
category: integration
tags: [wms, wise, auth, probe]
lazyLoad: true
---

# WMS Auth Probe

Run scripts/probe.mjs to verify that injected AUTH_TOKEN/IAM_TOKEN/WMS_BASE_URL are
available and accepted by the WISE gateway for read-only pulls on tenant LT,
facility LT_ORG-61213 (Joliet). Never print token values.
