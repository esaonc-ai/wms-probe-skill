#!/usr/bin/env node
// Read-only probe: check injected env and whether AUTH_TOKEN works against WISE.
const names = ["WMS_BASE_URL", "AUTH_TOKEN", "IAM_TOKEN", "TENANT_ID", "FACILITY_ID", "COMPANY_ID", "USER_ID", "MODEL", "ITEMGPT_REQUEST_CLIENT"];
for (const n of names) {
  const v = process.env[n];
  console.log(`${n}=${v === undefined || v === "" ? "(unset)" : "(set len " + v.length + ")"}`);
}
const base = (process.env.WMS_BASE_URL || "https://unis.item.com/api").replace(/\/+$/, "");
const auth = process.env.AUTH_TOKEN || process.env.IAM_TOKEN || "";
const tenant = process.env.TENANT_ID || "LT";
const facility = process.env.FACILITY_ID || "LT_ORG-61213";
console.log(`base=${base} tenant=${tenant} facility=${facility} authLen=${auth.length}`);

async function call(path, method, body) {
  try {
    const r = await fetch(base + path, {
      method,
      headers: {
        Authorization: "Bearer " + auth,
        "Content-Type": "application/json",
        Accept: "application/json",
        "x-tenant-id": tenant,
        "x-facility-id": facility,
        "item-time-zone": "America/Chicago",
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const t = await r.text();
    console.log(`[${method} ${path}] HTTP ${r.status} body=${t.slice(0, 400)}`);
    return { status: r.status, text: t };
  } catch (e) {
    console.log(`[${method} ${path}] ERROR ${e.message}`);
    return { status: 0, text: e.message };
  }
}

await call("/wms/exception-line/search", "POST", { tenantId: tenant, status: "PENDING", currentPage: 1, pageSize: 5 });
